#ifndef _USER_COMM_H
#define _USER_COMM_H


#include "main.h"


#define USART_COMM_TX_SIZE	50
#define USART_COMM_RX_SIZE	50


typedef struct
{
	uint8_t rev_ok;
	
	uint8_t robot_state;
	uint8_t chass_en;
	uint8_t chass_mode;
	int8_t chass_speed;
	int8_t chass_diff;
	uint8_t weapon_en;
	uint8_t weapon_keep;
	uint8_t weapon_mode;
	int8_t weapon_cur;
	int8_t weapon_spe;
	uint8_t rev_time;

}COMM_REV_TYPEDEF;


typedef struct
{
	uint8_t usart_tx_buf[USART_COMM_TX_SIZE];
	uint8_t usart_rx_buf[USART_COMM_RX_SIZE];				
	uint16_t rx_data_len;
	uint8_t init_ok;
	
	COMM_REV_TYPEDEF rev;
}COMM_TYPEDEF;

extern COMM_TYPEDEF COMM;
extern int turn_sense;


void User_CommInit(void);
void User_CommIRQHandler(void);
void User_CommDataParas(void);
void User_CommSendTask(void);

#endif










