#include "user_adc.h"
#include "adc.h"


 
USER_ADC_TYPE USER_ADC; 


void User_AdcInit(void)
{
//	HAL_ADCEx_Calibration_Start(&hadc1);//F1��ҪУ׼��F4������У׼������
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)USER_ADC.adc1_buf, ADC1_CH_NUM);

}

void User_Limit(int8_t* data,uint8_t limit)
{
	if(*data > limit)
		*data = limit;
	else if(*data < -limit)
		*data = -limit;
}

void User_AdcGetTask(void)
{
	static uint32_t temp[ADC1_CH_NUM];
	static uint8_t cnt = 0;
	static uint16_t avr[ADC1_CH_NUM];
	
	cnt++;
	
	if(cnt <= 100)
	{
		
	}
	else if((cnt > 100) && (cnt <= 228))
	{
		for(uint8_t i=0;i<ADC1_CH_NUM;i++)
		{
			temp[i] += USER_ADC.adc1_buf[i];
		}
	}
	else if(cnt == 229)
	{
		for(uint8_t i=0;i<ADC1_CH_NUM;i++)
		{
			avr[i] = temp[i]>>7;
		}
	}
	else if(cnt > 229)
	{
		cnt = 230;
		USER_ADC.hand_x1 = ((-(USER_ADC.adc1_buf[0] - avr[0])>>4)*100)>>7;
		USER_ADC.hand_y1 = (((USER_ADC.adc1_buf[1] - avr[1])>>4)*100)>>7;
		USER_ADC.hand_rp1 = (((4096-USER_ADC.adc1_buf[2])>>4)*100)>>8;
		USER_ADC.hand_rp2 = (((4096-USER_ADC.adc1_buf[3])>>4)*100)>>8;
		USER_ADC.hand_x2 = ((-(USER_ADC.adc1_buf[4] - avr[4])>>4)*100)>>7;
		USER_ADC.hand_y2 = (((USER_ADC.adc1_buf[5] - avr[5])>>4)*100)>>7;
		
		USER_ADC.ok = 1;
	}	
	else;
	
	User_Limit(&USER_ADC.hand_x1,100);
	User_Limit(&USER_ADC.hand_y1,100);
	User_Limit(&USER_ADC.hand_x2,100);
	User_Limit(&USER_ADC.hand_y2,100);
}





