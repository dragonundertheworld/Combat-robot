#include "user_comm.h" 
#include "usart.h"
#include "user_key.h"
#include "user_adc.h"

extern DMA_HandleTypeDef hdma_usart1_rx; 

#define USART_COMM_HUSART huart1
#define USART_COMM_HDMA_RX hdma_usart1_rx  

COMM_TYPEDEF COMM;  
int turn_sense=10;

void User_CommInit(void)
{               		
	__HAL_UART_CLEAR_IDLEFLAG(&USART_COMM_HUSART);
	__HAL_UART_ENABLE_IT(&USART_COMM_HUSART, UART_IT_IDLE);         
	HAL_UART_Receive_DMA(&USART_COMM_HUSART, (uint8_t*)COMM.usart_rx_buf, USART_COMM_RX_SIZE); 

	COMM.init_ok = 1;
}

void User_CommIRQHandler(void)
{	
	if(RESET != __HAL_UART_GET_FLAG(&USART_COMM_HUSART, UART_FLAG_IDLE))   
	{		
		__HAL_UART_CLEAR_IDLEFLAG(&USART_COMM_HUSART);    		
		HAL_UART_DMAStop(&USART_COMM_HUSART);                                                        
    COMM.rx_data_len  = USART_COMM_RX_SIZE - __HAL_DMA_GET_COUNTER(&USART_COMM_HDMA_RX);   
		User_CommDataParas();///////
		HAL_UART_Receive_DMA(&USART_COMM_HUSART, (uint8_t*)COMM.usart_rx_buf, USART_COMM_RX_SIZE);
	} 		
} 

void User_CommDataParas(void)
{
	uint8_t i = 0;
	uint8_t sum_check = 0;
	uint8_t add_check = 0;

	if((COMM.usart_rx_buf[0] == 0xAA) && (COMM.usart_rx_buf[1] == 0xFF) && (COMM.usart_rx_buf[2] == 0xF2))
	{	
		for(i=0;i<COMM.usart_rx_buf[3]+4;i++)
		{
			sum_check += COMM.usart_rx_buf[i];
			add_check += sum_check;
		}
		if((COMM.usart_rx_buf[COMM.usart_rx_buf[3]+4] == sum_check)&&(COMM.usart_rx_buf[COMM.usart_rx_buf[3]+5] == add_check))
		{
			COMM.rev.robot_state 	= COMM.usart_rx_buf[4];
			COMM.rev.chass_en 		= COMM.usart_rx_buf[5];
//			COMM.rev.chass_mode 	= COMM.usart_rx_buf[6];
			turn_sense 						= COMM.usart_rx_buf[6];
			COMM.rev.chass_speed 	= COMM.usart_rx_buf[7];
			COMM.rev.chass_diff 	= COMM.usart_rx_buf[8];
			COMM.rev.weapon_en 		= COMM.usart_rx_buf[9];
			COMM.rev.weapon_keep 	= COMM.usart_rx_buf[10];
			COMM.rev.weapon_mode 	= COMM.usart_rx_buf[11];
			COMM.rev.weapon_cur 	= COMM.usart_rx_buf[12];
			COMM.rev.weapon_spe 	= COMM.usart_rx_buf[13];
			COMM.rev.rev_time 		= COMM.usart_rx_buf[14];
					
			COMM.rev.rev_ok = 1;
		}
	}
	else;	
}

void User_CommSendTask(void)//
{
	uint8_t i = 0;
	uint8_t sum_check = 0;
	uint8_t add_check = 0;
	static uint8_t time = 0;
	
	COMM.usart_tx_buf[i++] = 0xAA;
	COMM.usart_tx_buf[i++] = 0xFF;
	COMM.usart_tx_buf[i++] = 0xF1;
	COMM.usart_tx_buf[i++] = 8;//�����ֽ���
	

		
	COMM.usart_tx_buf[i++] = KEY.value & 0x1F;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_x1;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_y1;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_rp1;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_rp2;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_x2;
	COMM.usart_tx_buf[i++] = USER_ADC.hand_y2;
	COMM.usart_tx_buf[i++] = time++;


	for(uint8_t j=0;j<(COMM.usart_tx_buf[3]+4);j++)
	{
		sum_check += COMM.usart_tx_buf[j];
		add_check += sum_check;
	}
	COMM.usart_tx_buf[i++] = sum_check;
	COMM.usart_tx_buf[i++] = add_check;
	
	HAL_UART_Transmit_DMA(&USART_COMM_HUSART,(uint8_t*)COMM.usart_tx_buf,i);
}


