#include "user_timer.h"
#include "tim.h"

//#include "user_led.h"
#include "user_key.h" 

#define _USER_HTIM_1MS		htim1
#define _USER_TIM_1MS			TIM1
#define _USER_HTIM_1US		htim2
#define _USER_TIM_1US			TIM2

void User_TimerInit(void)
{
	HAL_TIM_Base_Start_IT(&_USER_HTIM_1MS);//  		
}


void User_Timer1msIRQ(void)
{
	static uint16_t cnt = 0;
	cnt++;
	
	User_KeyCheck(); 
	
}

void TimerDelayUs(uint16_t us)
{
	_USER_TIM_1US->CNT = 0;
	HAL_TIM_Base_Start(&_USER_HTIM_1US); 	
	while(_USER_TIM_1US->CNT < us);
	HAL_TIM_Base_Stop(&_USER_HTIM_1US); 
}

void User_DelayMs(uint16_t ms)
{
	while(ms--)
		TimerDelayUs(1000);
}


