#include "user_key.h"
#include "user_led.h" 

KEY_TYPEDEF KEY;


void User_KeyInit(void)
{
	for(uint8_t i=0;i<5;i++)
	{
		KEY.state[i].level = 1;
		KEY.state[i].press_time = 0;
		KEY.state[i].trig = NONE;
	}
}

void User_KeyCheck(void)
{
	static uint8_t i=0;
	
	KEY.state[0].level = _KEY1_LEV;  
	KEY.state[1].level = _KEY2_LEV; 
	KEY.state[2].level = _KEY3_LEV;
	KEY.state[3].level = _KEY4_LEV; 
	KEY.state[4].level = _KEY5_LEV;
	
	for(uint8_t j=0;j<5;j++)
	{
		KEY.state[j].level?(KEY.value |= (1<<j)):(KEY.value &= ~(1<<j));
	}
	
	if(KEY.state[i].level == 0)//����״̬Ϊ0
	{
		KEY.state[i].press_time += _KEY_NUM;	
		BUZ.remain_ms = 30;
	}
	else
	{
		if(KEY.state[i].press_time <= 10)
		{			
//				KEY[i].trig = NONE;	//���������ã���Ϊ����Ч��ѹ����ܴ��ڶ������¼���һ����С��ʱ�����,��ʹ��Ч��ѹ״̬������ΪNONE!!			
		}
		else if((KEY.state[i].press_time > 10) && (KEY.state[i].press_time <= 1000))
		{
			KEY.state[i].trig = SHORT;	
		}
		else if((KEY.state[i].press_time > 1000) && (KEY.state[i].press_time <= 5000))
		{
			KEY.state[i].trig = MID;		
		}
		else if((KEY.state[i].press_time > 5000) && (KEY.state[i].press_time <= 10000))
		{
			KEY.state[i].trig = LONG;	
		}
		else if(KEY.state[i].press_time > 10000)
			KEY.state[i].trig = NONE;
		
		KEY.state[i].press_time = 0;
	}
	
	i++;
	if(i == _KEY_NUM)
		i = 0;

}

void User_Key1Deal(void)
{
	
	switch(KEY.state[0].trig)
	{
		case NONE:;break;
		case SHORT:	
		{
			//User_MoveOdomReset();
		}break;
		case MID:
		{
			
		}break;
		case LONG:
		{

		}break;
		default:
		{
			
		}break;
	}
	KEY.state[0].trig = NONE;
}

void User_Key2Deal(void)
{
	switch(KEY.state[1].trig)
	{
		case NONE:;break;
		case SHORT:	
		{

		}break;
		case MID:
		{

		}break;
		case LONG:
		{

		}break;
		default:
		{
		}break;
	}
	KEY.state[1].trig = NONE;
		
}

void User_Key3Deal(void)
{
	static uint8_t state = 0;
	
	switch (state)
	{
		case 0:
		{
			if(KEY.state[2].trig == SHORT)
			{
				state++;
			}
			else;
			
		}break;
		case 1:
		{
			
			if(KEY.state[2].trig == SHORT)
			{
				state++;
			}
		}break;
		case 2:
		{
			
			if(KEY.state[2].trig == SHORT)
			{
				state++;
			}
		}break;
		case 3:
		{
			
			if(KEY.state[2].trig == SHORT)
			{
				state++;
			}
		}break;
		case 4:
		{
			
			if(KEY.state[2].trig == SHORT)
			{
				state = 0;
				
			}
		}break;
		default:state = 0;break;
	}
	
	if(KEY.state[2].trig == LONG)
		;
	
	KEY.state[2].trig = NONE;
		
}



