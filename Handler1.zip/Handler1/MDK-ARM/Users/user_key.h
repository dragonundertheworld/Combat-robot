#ifndef _user_key_h
#define _user_key_h

#include "main.h"



#define _KEY1_LEV 		HAL_GPIO_ReadPin(SW1_GPIO_Port, SW1_Pin)
#define _KEY2_LEV 		HAL_GPIO_ReadPin(SW2_GPIO_Port, SW2_Pin)
#define _KEY3_LEV 		HAL_GPIO_ReadPin(SW3_GPIO_Port, SW3_Pin)
#define _KEY4_LEV 		HAL_GPIO_ReadPin(SW4_GPIO_Port, SW4_Pin)
#define _KEY5_LEV 		HAL_GPIO_ReadPin(SW5_GPIO_Port, SW5_Pin)


#define _KEY_NUM 5 


typedef enum
{
	NONE,
	SHORT,
	MID,
	LONG
}KEY_TRIG_TYPE;


typedef struct
{
	KEY_TRIG_TYPE trig;
	uint8_t level;
	uint32_t press_time;
}KEY_STATE_TYPEDEF;

typedef struct
{
	KEY_STATE_TYPEDEF state[_KEY_NUM];
	uint8_t value;
}KEY_TYPEDEF;

extern KEY_TYPEDEF KEY;



void User_KeyInit(void);
void User_KeyCheck(void);

void User_Key1Deal(void);
void User_Key2Deal(void);
void User_Key3Deal(void);
void User_Key4Deal(void);
void User_Key5Deal(void);

#endif










