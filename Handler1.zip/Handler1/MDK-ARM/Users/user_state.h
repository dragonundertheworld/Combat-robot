#ifndef _user_state_h
#define _user_state_h

#include "main.h"







typedef struct
{
	uint8_t mode;	
	uint8_t hold;
	int8_t value;
}ATTACK_WORK_TYPEDEF;
extern ATTACK_WORK_TYPEDEF ATTACK;

typedef struct
{
	uint8_t close_loop;	
	int8_t spe_lin;
	int8_t spe_ang;
	int8_t sensi;
}CHASS_WORK_TYPEDEF;
extern CHASS_WORK_TYPEDEF CHASS;

typedef struct
{
	uint8_t now;	
	uint8_t next;
	uint8_t last;
}STATE_TYPEDEF;
extern STATE_TYPEDEF STATE;

typedef struct
{
	float x;
	float y;
}POINT_TYPEDEF;
extern POINT_TYPEDEF POINT[14];

void User_StateMachineInit(void);
void User_StateMachineRun(void);

#endif

