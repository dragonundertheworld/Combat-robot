#ifndef _user_adc_h
#define _user_adc_h

#include "main.h"

#define ADC1_CH_NUM	6

typedef struct
{
	uint16_t adc1_buf[ADC1_CH_NUM];	
	
	int8_t hand_x1;
	int8_t hand_y1;
	int8_t hand_x2;
	int8_t hand_y2;
	int8_t hand_rp1;
	int8_t hand_rp2;
	
	uint8_t ok;
}USER_ADC_TYPE;
extern USER_ADC_TYPE USER_ADC;


void User_AdcInit(void);
void User_AdcGetTask(void);

#endif










